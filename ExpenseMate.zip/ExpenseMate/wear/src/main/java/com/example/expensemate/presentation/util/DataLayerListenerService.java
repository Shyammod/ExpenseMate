package com.example.expensemate.presentation.util;

import android.util.Log;

import com.example.expensemate.presentation.helper.PreferenceHelper;
import com.example.expensemate.presentation.model.Transaction;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class DataLayerListenerService extends WearableListenerService {
    private static final String TAG = "WearDataLayerService";

    @Override
    public void onDataChanged(DataEventBuffer dataEvents) {
        for (DataEvent event : dataEvents) {
            if (event.getType() == DataEvent.TYPE_CHANGED) {
                DataItem item = event.getDataItem();
                if ("/transactions".equals(item.getUri().getPath())) {
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    String source = dataMap.getString("source", "");
                    long timestamp = dataMap.getLong("timestamp", 0);


                    if ("wear".equals(source)) {
                        return;
                    }

                    PreferenceHelper helper = new PreferenceHelper(getApplicationContext());
                    if (timestamp > helper.getLastUpdateTimestamp()) {
                        String transactionsJson = dataMap.getString("transactions_json");
                        Type listType = new TypeToken<List<Transaction>>() {}.getType();
                        List<Transaction> transactions = new Gson().fromJson(transactionsJson, listType);
                        helper.saveTransactionsLocal(transactions, timestamp);
                        Log.d(TAG, "Transactions updated from Mobile");
                    } else {
                        Log.d(TAG, "Ignored older transaction update");
                    }
                }
            }
        }
    }
}