package com.example.expensemate.presentation.model;

import java.io.Serializable;
import java.util.UUID;

public class Transaction implements Serializable {

    private long id;               // Unique identifier
    private String title;
    private Category category;
    private double amount;
    private TransactionType type;


    public Transaction() {}


    public Transaction(String title, Category category, double amount, TransactionType type) {
        this.id = System.currentTimeMillis(); // or use UUID.randomUUID().getMostSignificantBits() for long
        this.title = title;
        this.category = category;
        this.amount = amount;
        this.type = type;
    }


    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public TransactionType getType() { return type; }
    public void setType(TransactionType type) { this.type = type; }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Transaction)) return false;
        Transaction other = (Transaction) obj;
        return this.id == other.id;
    }

    @Override
    public int hashCode() {
        return Long.valueOf(id).hashCode();
    }
}