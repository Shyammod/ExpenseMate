package com.example.expensemate.presentation.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.expensemate.presentation.model.Transaction;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PreferenceHelper {
    private static final String PREFS_NAME = "expense_mate_prefs_wear";
    private static final String TRANSACTIONS_KEY = "transactions";
    private static final String TIMESTAMP_KEY = "last_update_timestamp";
    private static final String TAG = "PreferenceHelperWear";

    private final SharedPreferences preferences;
    private final Gson gson;
    private final Context appContext;

    public PreferenceHelper(Context context) {
        this.appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public List<Transaction> getTransactions() {
        String json = preferences.getString(TRANSACTIONS_KEY, "");
        if (json.isEmpty()) {
            return new ArrayList<>();
        }
        Type listType = new TypeToken<List<Transaction>>() {}.getType();
        return gson.fromJson(json, listType);
    }

    public long getLastUpdateTimestamp() {
        return preferences.getLong(TIMESTAMP_KEY, 0);
    }

    public void saveTransactionsLocal(List<Transaction> transactions, long timestamp) {
        preferences.edit()
                .putString(TRANSACTIONS_KEY, gson.toJson(transactions))
                .putLong(TIMESTAMP_KEY, timestamp)
                .apply();
    }

    public void saveTransactionsAndSync(List<Transaction> transactions) {
        long timestamp = System.currentTimeMillis();
        saveTransactionsLocal(transactions, timestamp);
        syncToMobile(transactions, timestamp);
    }

    public void addTransaction(Transaction transaction) {
        List<Transaction> transactions = getTransactions();
        transactions.add(transaction);
        saveTransactionsAndSync(transactions);
    }

    public void deleteTransaction(Transaction transaction) {
        List<Transaction> transactions = getTransactions();
        transactions.remove(transaction);
        saveTransactionsAndSync(transactions);
    }

    private void syncToMobile(List<Transaction> transactions, long timestamp) {
        try {
            PutDataMapRequest putDataMapReq = PutDataMapRequest.create("/transactions");
            putDataMapReq.getDataMap().putString("transactions_json", gson.toJson(transactions));
            putDataMapReq.getDataMap().putLong("timestamp", timestamp);
            putDataMapReq.getDataMap().putString("source", "wear");

            PutDataRequest putDataReq = putDataMapReq.asPutDataRequest().setUrgent();

            Task<DataItem> task = Wearable.getDataClient(appContext).putDataItem(putDataReq);
            task.addOnSuccessListener(dataItem -> Log.d(TAG, "Synced to Mobile: " + dataItem.getUri()))
                    .addOnFailureListener(e -> Log.e(TAG, "Failed to sync to Mobile", e));
        } catch (Exception e) {
            Log.e(TAG, "Exception syncing to Mobile", e);
        }
    }
}