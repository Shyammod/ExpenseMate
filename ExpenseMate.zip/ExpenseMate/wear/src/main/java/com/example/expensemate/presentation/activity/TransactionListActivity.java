package com.example.expensemate.presentation.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import androidx.wear.widget.WearableRecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.presentation.model.Transaction;
import com.example.expensemate.presentation.adapter.TransactionWearAdapter;
import com.example.expensemate.presentation.helper.PreferenceHelper;

import java.util.List;

public class TransactionListActivity extends Activity
        implements TransactionWearAdapter.OnTransactionClickListener {

    private WearableRecyclerView recyclerView;
    private TransactionWearAdapter adapter;
    private PreferenceHelper preferenceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_list);

        recyclerView = findViewById(R.id.recyclerViewTransactions);
        recyclerView.setEdgeItemsCenteringEnabled(true);
        recyclerView.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));

        adapter = new TransactionWearAdapter(this);
        adapter.setClickListener(this); // set class-level click listener
        recyclerView.setAdapter(adapter);

        preferenceHelper = new PreferenceHelper(this);

        loadTransactionsFromPreferences();
    }

    private void loadTransactionsFromPreferences() {
        List<Transaction> transactions = preferenceHelper.getTransactions();
        Toast.makeText(this, "Transactions size: " + (transactions == null ? 0 : transactions.size()), Toast.LENGTH_SHORT).show();

        if (transactions == null || transactions.isEmpty()) {
            Toast.makeText(this, "No transactions found", Toast.LENGTH_SHORT).show();
        } else {
            adapter.setTransactions(transactions);
        }
    }

    // Adapter click interface method
    @Override
    public void onTransactionClick(Transaction transaction) {
        preferenceHelper.deleteTransaction(transaction);
        Toast.makeText(this, "Transaction deleted", Toast.LENGTH_SHORT).show();
        loadTransactionsFromPreferences();
    }
}
