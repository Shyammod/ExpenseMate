package com.example.expensemate.presentation.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.expensemate.R;
import com.example.expensemate.presentation.model.Category;
import com.example.expensemate.presentation.model.Transaction;
import com.example.expensemate.presentation.model.TransactionType;
import com.example.expensemate.presentation.helper.PreferenceHelper;

import java.util.ArrayList;
import java.util.List;

public class AddTransactionActivityWear extends Activity implements View.OnClickListener {

    private EditText etTitle, etAmount;
    private Spinner spinnerCategory;
    private Button btnSave;
    private TransactionType transactionType;

    private PreferenceHelper preferenceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction_wear);

        etTitle = findViewById(R.id.etTitle);
        etAmount = findViewById(R.id.etAmount);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnSave = findViewById(R.id.btnSave);

        preferenceHelper = new PreferenceHelper(this);

        String typeStr = getIntent().getStringExtra("transaction_type");
        if (typeStr == null) {
            finish();
            return;
        }
        transactionType = TransactionType.valueOf(typeStr);

        setupCategorySpinner();

        // Set listener at parent level
        btnSave.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSave) {
            String title = etTitle.getText().toString().trim();
            String amountStr = etAmount.getText().toString().trim();
            Category category = (Category) spinnerCategory.getSelectedItem();

            if (title.isEmpty() || amountStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
                return;
            }

            Transaction transaction = new Transaction(title, category, amount, transactionType);
            preferenceHelper.addTransaction(transaction);

            Toast.makeText(this, "Transaction added successfully", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupCategorySpinner() {
        List<Category> categories = new ArrayList<>();
        for (Category cat : Category.values()) {
            if (cat.getType() == transactionType) {
                categories.add(cat);
            }
        }

        ArrayAdapter<Category> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);
    }
}
