package com.example.expensemate.presentation.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}

