package com.example.expensemate.presentation.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.expensemate.R;
import com.example.expensemate.presentation.model.TransactionType;

public class MainActivity extends Activity implements View.OnClickListener {

    // UI elements for adding income, adding expense, and viewing transaction list
    private ImageButton btnAddIncome, btnAddExpense;
    private Button btnListTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Load the layout for the main screen

        // Link UI elements from layout XML to Java code
        btnAddIncome = findViewById(R.id.btnAddIncome);
        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnListTransaction = findViewById(R.id.btnListTransaction);

        // Set click listeners for all buttons
        btnAddIncome.setOnClickListener(this);
        btnAddExpense.setOnClickListener(this);
        btnListTransaction.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v == btnAddIncome) {
            // Start AddTransactionActivityWear for adding income
            Intent intent = new Intent(this, AddTransactionActivityWear.class);
            intent.putExtra("transaction_type", TransactionType.INCOME.name());
            startActivity(intent);

        } else if (v == btnAddExpense) {
            // Start AddTransactionActivityWear for adding expense
            Intent intent = new Intent(this, AddTransactionActivityWear.class);
            intent.putExtra("transaction_type", TransactionType.EXPENSE.name());
            startActivity(intent);

        } else if (v == btnListTransaction) {
            // Open the transaction list screen
            startActivity(new Intent(this, TransactionListActivity.class));
        }
    }
}
