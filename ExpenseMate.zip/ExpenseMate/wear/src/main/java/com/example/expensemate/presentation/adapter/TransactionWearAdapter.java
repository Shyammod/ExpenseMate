package com.example.expensemate.presentation.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.wear.widget.WearableRecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.presentation.helper.PreferenceHelper;
import com.example.expensemate.presentation.model.Transaction;

import java.util.ArrayList;
import java.util.List;

public class TransactionWearAdapter extends WearableRecyclerView.Adapter<TransactionWearAdapter.ViewHolder> {

    private List<Transaction> transactions = new ArrayList<>();
    private final Context context;
    private OnTransactionClickListener clickListener; // class-level listener

    public TransactionWearAdapter(Context context) {
        this.context = context;
    }

    // Interface for item click / delete actions
    public interface OnTransactionClickListener {
        void onTransactionClick(Transaction transaction); // e.g., delete or view
    }

    // Set the listener from activity
    public void setClickListener(OnTransactionClickListener listener) {
        this.clickListener = listener;
    }

    // Update transactions list
    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions != null ? transactions : new ArrayList<>();
        Log.d("TransactionAdapter", "Transactions count: " + this.transactions.size());
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_transaction_wear, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);

        holder.tvTitle.setText(transaction.getTitle() != null ? transaction.getTitle() : "No Title");
        holder.tvCategory.setText(transaction.getCategory() != null ? transaction.getCategory().name() : "No Category");
        holder.tvAmount.setText(String.format("$%.2f", transaction.getAmount()));

        // Delete button click
        holder.btnDelete.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onTransactionClick(transaction); // notify activity
            }
        });
    }

    @Override
    public int getItemCount() {
        return transactions != null ? transactions.size() : 0;
    }

    // ViewHolder class
    static class ViewHolder extends WearableRecyclerView.ViewHolder {
        TextView tvTitle, tvCategory, tvAmount;
        Button btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
