package com.example.expensemate.presentation.data;

import android.content.Context;

import com.example.expensemate.presentation.model.Transaction;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.MessageClient;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class DataLayerHelper implements DataClient.OnDataChangedListener, MessageClient.OnMessageReceivedListener {

    private static final String TRANSACTIONS_PATH = "/transactions";
    private static final String TRANSACTIONS_KEY = "transactions";

    private static DataLayerHelper instance;
    private final Context context;
    private final Gson gson = new Gson();
    private TransactionListener listener;

    private DataLayerHelper(Context context) {
        this.context = context.getApplicationContext();
        Wearable.getDataClient(context).addListener(this);
        Wearable.getMessageClient(context).addListener(this);
    }

    public static DataLayerHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DataLayerHelper(context);
        }
        return instance;
    }

    public void setTransactionListener(TransactionListener listener) {
        this.listener = listener;
    }

    public void requestTransactions() {
        Wearable.getNodeClient(context).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node node : nodes) {
                Wearable.getMessageClient(context).sendMessage(node.getId(), "/get_transactions", new byte[0]);
            }
        });
    }

    public void addTransaction(Transaction transaction) {
        String json = gson.toJson(transaction);
        Wearable.getNodeClient(context).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node node : nodes) {
                Wearable.getMessageClient(context).sendMessage(node.getId(), "/add_transaction", json.getBytes());
            }
        });
    }

    @Override
    public void onDataChanged(DataEventBuffer dataEvents) {
        for (com.google.android.gms.wearable.DataEvent event : dataEvents) {
            if (event.getType() == com.google.android.gms.wearable.DataEvent.TYPE_CHANGED) {
                DataItem item = event.getDataItem();
                if (item.getUri().getPath().equals(TRANSACTIONS_PATH)) {
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    String json = dataMap.getString(TRANSACTIONS_KEY);
                    Type listType = new TypeToken<List<Transaction>>() {}.getType();
                    List<Transaction> transactions = gson.fromJson(json, listType);
                    if (listener != null) {
                        listener.onTransactionsUpdated(transactions);
                    }
                }
            }
        }
    }

    @Override
    public void onMessageReceived(com.google.android.gms.wearable.MessageEvent messageEvent) {
        // Optionally handle messages from phone
    }

    public interface TransactionListener {
        void onTransactionsUpdated(List<Transaction> transactions);
        void onError(String message);
    }
}
