package com.example.expensemate.model;

public enum Category {


    SALARY(TransactionType.INCOME),
    GIFTS(TransactionType.INCOME),
    BONUS(TransactionType.INCOME),


    ENTERTAINMENT(TransactionType.EXPENSE),
    GAS(TransactionType.EXPENSE),
    UTILITIES(TransactionType.EXPENSE);

    private final TransactionType type;

    Category(TransactionType type) {
        this.type = type;
    }

    public TransactionType getType() {
        return type;
    }
}

