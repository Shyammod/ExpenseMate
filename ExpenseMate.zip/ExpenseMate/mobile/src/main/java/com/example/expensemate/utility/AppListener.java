package com.example.expensemate.utility;

public interface AppListener {
    void onExpenseExceeded();
}

