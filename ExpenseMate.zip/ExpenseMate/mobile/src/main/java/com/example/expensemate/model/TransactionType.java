package com.example.expensemate.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}
