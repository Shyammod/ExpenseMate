package com.example.expensemate.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.expensemate.R;
import com.example.expensemate.adapter.TransactionAdapter;
import com.example.expensemate.databinding.ActivityMainBinding;
import com.example.expensemate.helper.PreferenceHelper;
import com.example.expensemate.model.Transaction;
import com.example.expensemate.model.TransactionType;
import com.example.expensemate.utility.AppListener;
import com.example.expensemate.utility.NotificationUtil;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// MainActivity for displaying transactions, balance, and charts
public class MainActivity extends AppCompatActivity implements AppListener {

    // View binding for accessing layout views
    private ActivityMainBinding binding;

    // Helper for saving/retrieving data from SharedPreferences
    private PreferenceHelper preferenceHelper;

    private TransactionAdapter adapter;


    private Button buttonPieChart, buttonBarChart;


    private PieChart pieChart;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        initBindingAndHelpers();


        setupNotificationChannel();


        requestNotificationPermissionIfNeeded();


        setupRecyclerView();


        setupButtonListeners();


        setupChartToggleButtons();


        refreshUI();
    }

    // Link layout views and helper classes
    private void initBindingAndHelpers() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        preferenceHelper = new PreferenceHelper(this);

        // Get references to buttons and charts from layout
        buttonPieChart = binding.buttonPieChart;
        buttonBarChart = binding.buttonBarChart;
        pieChart = binding.pieChart;
        barChart = binding.barChart;
    }


    private void setupNotificationChannel() {
        NotificationUtil.createNotificationChannel(this);
    }

    // Request runtime permission for notifications (Android 13+)
    private void requestNotificationPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    1001
            );
        }
    }

    // Setup RecyclerView to show transactions
    private void setupRecyclerView() {
        binding.recyclerViewTransactions.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransactionAdapter(this);
        binding.recyclerViewTransactions.setAdapter(adapter);

        // Handle delete button click inside each transaction
        adapter.setOnDeleteClickListener(transaction -> {
            preferenceHelper.deleteTransaction(transaction); // Remove from storage
            refreshUI(); // Refresh list and charts
        });
    }

    // Setup Add Income / Add Expense button clicks
    private void setupButtonListeners() {
        binding.buttonAddIncome.setOnClickListener(v ->
                AddTransactionActivity.start(this, TransactionType.INCOME));

        binding.buttonAddExpense.setOnClickListener(v ->
                AddTransactionActivity.start(this, TransactionType.EXPENSE));
    }

    // Setup chart toggle functionality between Pie and Bar chart
    private void setupChartToggleButtons() {
        buttonPieChart.setOnClickListener(v -> {
            pieChart.setVisibility(View.VISIBLE);
            barChart.setVisibility(View.GONE);

            buttonPieChart.setEnabled(false);
            buttonBarChart.setEnabled(true);
            refreshUI(); // Refresh chart data
        });

        buttonBarChart.setOnClickListener(v -> {
            pieChart.setVisibility(View.GONE);
            barChart.setVisibility(View.VISIBLE);

            buttonPieChart.setEnabled(true);
            buttonBarChart.setEnabled(false);
            refreshUI(); // Refresh chart data
        });


        buttonPieChart.setEnabled(false);
        buttonBarChart.setEnabled(true);
        pieChart.setVisibility(View.VISIBLE);
        barChart.setVisibility(View.GONE);
    }

    // Refresh transaction list, balance, and charts
    private void refreshUI() {
        // Get saved transactions
        List<Transaction> transactions = preferenceHelper.getTransactions();
        adapter.setTransactions(transactions);

        boolean hasTransactions = !transactions.isEmpty();

        // Show/hide "no transactions" message
        binding.textNoTransactions.setVisibility(hasTransactions ? View.GONE : View.VISIBLE);
        binding.recyclerViewTransactions.setVisibility(hasTransactions ? View.VISIBLE : View.GONE);

        // Calculate totals
        double totalIncome = calculateTotal(transactions, TransactionType.INCOME);
        double totalExpense = calculateTotal(transactions, TransactionType.EXPENSE);
        double balance = totalIncome - totalExpense;

        if (!hasTransactions) {
            balance = 0.0;
        }


        updateBalanceUI(balance);

        // Show appropriate chart
        if (pieChart.getVisibility() == View.VISIBLE) {
            setupPieChart(transactions);
        } else {
            setupBarChart(transactions);
        }


        if (totalExpense > totalIncome) {
            onExpenseExceeded();
        }
    }

    // Calculate total income or expense
    private double calculateTotal(List<Transaction> transactions, TransactionType type) {
        return transactions.stream()
                .filter(t -> t.getType() == type)
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    // Update balance text and color based on value
    private void updateBalanceUI(double balance) {
        binding.textBalance.setText(String.format("$%.2f", balance));

        if (balance > 0) {
            binding.textBalance.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else if (balance < 0) {
            binding.textBalance.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        } else {
            binding.textBalance.setTextColor(Color.DKGRAY);
        }
    }

    // Setup Pie Chart data and appearance
    private void setupPieChart(List<Transaction> transactions) {
        Map<String, Float> categoryTotals = calculateCategoryTotals(transactions);
        List<PieEntry> entries = buildPieEntries(categoryTotals);

        PieDataSet dataSet = new PieDataSet(entries, "Expenses by Category");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);

        PieData data = new PieData(dataSet);
        data.setValueTextSize(12f);
        data.setValueTextColor(Color.WHITE);

        pieChart.setData(data);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setTransparentCircleRadius(61f);
        pieChart.invalidate(); // Refresh chart
    }

    // Calculate total expense per category
    private Map<String, Float> calculateCategoryTotals(List<Transaction> transactions) {
        Map<String, Float> categoryTotals = new HashMap<>();
        for (Transaction t : transactions) {
            if (t.getType() == TransactionType.EXPENSE) {
                String category = t.getCategory().toString();
                float amount = (float) t.getAmount();
                categoryTotals.put(category, categoryTotals.getOrDefault(category, 0f) + amount);
            }
        }
        return categoryTotals;
    }

    // Convert category totals into PieEntry list for chart
    private List<PieEntry> buildPieEntries(Map<String, Float> categoryTotals) {
        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Float> entry : categoryTotals.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }
        return entries;
    }

    // Setup Bar Chart data and appearance
    private void setupBarChart(List<Transaction> transactions) {
        Map<String, Float> categoryTotals = calculateCategoryTotals(transactions);

        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        int index = 0;
        for (Map.Entry<String, Float> entry : categoryTotals.entrySet()) {
            entries.add(new BarEntry(index, entry.getValue()));
            labels.add(entry.getKey());
            index++;
        }

        BarDataSet dataSet = new BarDataSet(entries, "Expenses by Category");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.9f);

        barChart.setData(data);
        barChart.getDescription().setEnabled(false);
        barChart.setFitBars(true);
        barChart.invalidate(); // Refresh chart
    }

    // Called when expenses exceed income
    @Override
    public void onExpenseExceeded() {
        NotificationUtil.sendExpenseExceededNotification(this);
    }

    // Refresh UI when activity comes back into view
    @Override
    protected void onResume() {
        super.onResume();
        refreshUI();
    }
}
