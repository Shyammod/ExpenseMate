package com.example.expensemate.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.expensemate.model.Transaction;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PreferenceHelper {
    private static final String PREFS_NAME = "expense_mate_prefs";
    private static final String TRANSACTIONS_KEY = "transactions";
    private static final String TIMESTAMP_KEY = "last_update_timestamp";
    private static final String TAG = "PreferenceHelperMobile";

    private final SharedPreferences preferences;
    private final Gson gson;
    private final Context appContext;

    public PreferenceHelper(Context context) {
        this.appContext = context.getApplicationContext();
        this.preferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.gson = new Gson();
    }

    public List<Transaction> getTransactions() {
        String json = preferences.getString(TRANSACTIONS_KEY, "");
        if (json.isEmpty()) {
            return new ArrayList<>();
        }
        Type listType = new TypeToken<List<Transaction>>() {}.getType();
        return gson.fromJson(json, listType);
    }

    public long getLastUpdateTimestamp() {
        return preferences.getLong(TIMESTAMP_KEY, 0);
    }

    public void saveTransactionsLocal(List<Transaction> transactions, long timestamp) {
        String json = gson.toJson(transactions);
        preferences.edit()
                .putString(TRANSACTIONS_KEY, json)
                .putLong(TIMESTAMP_KEY, timestamp)
                .apply();
    }

    public void saveTransactionsAndSync(List<Transaction> transactions) {
        long timestamp = System.currentTimeMillis();
        saveTransactionsLocal(transactions, timestamp);
        syncToWear(transactions, timestamp);
    }

    public void addTransaction(Transaction transaction) {
        List<Transaction> transactions = getTransactions();
        transactions.add(transaction);
        saveTransactionsAndSync(transactions);
    }

    public void deleteTransaction(Transaction transaction) {
        List<Transaction> transactions = getTransactions();
        long targetId = transaction.getId();

        for (int i = 0; i < transactions.size(); i++) {
            if (transactions.get(i).getId() == targetId) {
                transactions.remove(i);
                break;
            }
        }

        saveTransactionsAndSync(transactions);
    }

    private void syncToWear(List<Transaction> transactions, long timestamp) {
        try {
            PutDataMapRequest putDataMapReq = PutDataMapRequest.create("/transactions");
            putDataMapReq.getDataMap().putString("transactions_json", gson.toJson(transactions));
            putDataMapReq.getDataMap().putLong("timestamp", timestamp);
            putDataMapReq.getDataMap().putString("source", "mobile");

            PutDataRequest putDataReq = putDataMapReq.asPutDataRequest().setUrgent();

            Wearable.getDataClient(appContext)
                    .putDataItem(putDataReq)
                    .addOnSuccessListener(dataItem -> Log.d(TAG, "Synced to Wear: " + dataItem.getUri()))
                    .addOnFailureListener(e -> Log.e(TAG, "Failed to sync to Wear", e));
        } catch (Exception e) {
            Log.e(TAG, "Exception syncing to Wear", e);
        }
    }
}