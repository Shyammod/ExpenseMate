package com.example.expensemate.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.databinding.ItemTransactionBinding;
import com.example.expensemate.model.Transaction;
import com.example.expensemate.model.TransactionType;

import java.util.ArrayList;
import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    private List<Transaction> transactions = new ArrayList<>();
    private final Context context;
    private OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(Transaction transaction);
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.deleteClickListener = listener;
    }

    public TransactionAdapter(Context context) {
        this.context = context;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTransactionBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.item_transaction,
                parent,
                false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);
        holder.binding.textTitle.setText(transaction.getTitle());
        holder.binding.textCategory.setText(transaction.getCategory().name());
        holder.binding.textAmount.setText(formatAmount(transaction.getAmount()));


        if (transaction.getType() == TransactionType.INCOME) {
            int green = context.getResources().getColor(android.R.color.holo_green_dark);
            holder.binding.imageIcon.setImageResource(R.drawable.ic_income);
            holder.binding.imageIcon.setColorFilter(green);
            holder.binding.textAmount.setTextColor(green);
        } else {
            int red = context.getResources().getColor(android.R.color.holo_red_dark);
            holder.binding.imageIcon.setImageResource(R.drawable.ic_expense);
            holder.binding.imageIcon.setColorFilter(red);
            holder.binding.textAmount.setTextColor(red);
        }


        holder.binding.buttonDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(transaction);
            }
        });
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    private String formatAmount(double amount) {
        return String.format("$%.2f", amount);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemTransactionBinding binding;

        public ViewHolder(ItemTransactionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

