package com.example.expensemate.utility;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;

import androidx.core.app.NotificationCompat;

public class NotificationUtil {
    private static final String CHANNEL_ID = "expense_channel";
    private static final int NOTIFICATION_ID = 100;

    public static void createNotificationChannel(Context context) {
        NotificationChannel channel = buildNotificationChannel();
        NotificationManager manager = getNotificationManager(context);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private static NotificationChannel buildNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Expense Notifications",
                NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Notifications for expense alerts");
        channel.enableLights(true);
        channel.setLightColor(Color.RED);
        return channel;
    }

    public static void sendExpenseExceededNotification(Context context) {
        NotificationCompat.Builder builder = buildExpenseExceededNotification(context);
        NotificationManager manager = getNotificationManager(context);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, builder.build());
        }
    }

    private static NotificationCompat.Builder buildExpenseExceededNotification(Context context) {
        return new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Expense Limit Exceeded")
                .setContentText("Your expenses have exceeded your income!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
    }

    private static NotificationManager getNotificationManager(Context context) {
        return (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }
}
