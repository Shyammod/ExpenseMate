package com.example.expensemate.activity;

import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.expensemate.R;
import com.example.expensemate.databinding.ActivityAddTransactionBinding;
import com.example.expensemate.helper.PreferenceHelper;
import com.example.expensemate.model.Category;
import com.example.expensemate.model.Transaction;
import com.example.expensemate.model.TransactionType;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AddTransactionActivity extends AppCompatActivity {

    private static final String EXTRA_TYPE = "transaction_type";

    private ActivityAddTransactionBinding binding;
    private PreferenceHelper preferenceHelper;
    private TransactionType transactionType;

    public static void start(Context context, TransactionType type) {
        Intent intent = new Intent(context, AddTransactionActivity.class);
        intent.putExtra(EXTRA_TYPE, type.name());
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initBindingAndHelper();
        extractTransactionTypeOrFinish();
        setupCategorySpinner();
        setupSaveButtonListener();
    }


    private void initBindingAndHelper() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_transaction);
        preferenceHelper = new PreferenceHelper(this);
    }

    private void extractTransactionTypeOrFinish() {
        String typeString = getIntent().getStringExtra(EXTRA_TYPE);
        if (typeString == null) {
            finish();
            return;
        }
        transactionType = TransactionType.valueOf(typeString);
    }


    private void setupCategorySpinner() {
        List<Category> categories = getCategoriesForTransactionType();
        ArrayAdapter<Category> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerCategory.setAdapter(adapter);
    }

    private List<Category> getCategoriesForTransactionType() {
        return Arrays.stream(Category.values())
                .filter(cat -> cat.getType() == transactionType)
                .collect(Collectors.toList());
    }

    private void setupSaveButtonListener() {
        binding.buttonSave.setOnClickListener(v -> saveTransaction());
    }


    private void saveTransaction() {
        String title = binding.editTextTitle.getText().toString().trim();
        String amountStr = binding.editTextAmount.getText().toString().trim();
        Category category = (Category) binding.spinnerCategory.getSelectedItem();

        if (!validateInput(title, amountStr)) {
            return;
        }

        double amount = parseAmount(amountStr);
        if (amount < 0) {
            showToast("Invalid amount");
            return;
        }

        persistTransaction(title, category, amount);
        finish();
    }

    private boolean validateInput(String title, String amountStr) {
        if (title.isEmpty()) {
            showToast("Please enter title");
            return false;
        }
        if (amountStr.isEmpty()) {
            showToast("Please enter amount");
            return false;
        }
        return true;
    }

    private double parseAmount(String amountStr) {
        try {
            return Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void persistTransaction(String title, Category category, double amount) {
        long id = System.currentTimeMillis();
        Transaction transaction = new Transaction(id, title, amount, transactionType, category, id);
        preferenceHelper.addTransaction(transaction);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
